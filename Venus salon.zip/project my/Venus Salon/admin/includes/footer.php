<footer>
    <div class="footer">
       <p>&copy; 2024 Venus Admin Dashboard.</p>
    </div>
        <footer>